# 🔍 Agora você sabe — Busca Inteligente CBS

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Supabase](https://img.shields.io/badge/Supabase-3ECF8E?style=for-the-badge&logo=supabase&logoColor=white)
![GitHub Pages](https://img.shields.io/badge/GitHub_Pages-222222?style=for-the-badge&logo=githubpages&logoColor=white)

**👉 [Acessar o site](https://danilobuch.github.io/agora-voce-sabe/)**

Ferramenta interna da **CBS** para encontrar produtos pelo código, pela descrição técnica, pela referência do fornecedor ou pelo **apelido comercial** (as tags), em milissegundos.

## 🎯 O problema

No comercial de suprimentos médicos há um descompasso entre a linguagem de quem vende (apelidos como "Transofix") e a do sistema (SKUs e descrições técnicas longas). Resultado: dependência de pessoas seniores, cotações lentas e excesso de perguntas nos grupos de comunicação.

## 💡 A solução

Uma aplicação web estática que carrega a base de produtos e filtra tudo localmente no navegador, como um "filtro de ruído" entre o vocabulário comercial e o técnico.

### Busca (site público)

- **Busca por partículas:** os termos podem vir em qualquer ordem. `000437 sonda` e `sonda 04` levam ao mesmo produto.
- **Busca avançada:** `"luva procedimento"` entre aspas busca o **trecho exato**, nessa ordem; `luva -latex` (hífen antes da palavra) **tira** da lista quem tem "latex" (também vale `-"trecho"`). O hífen só conta no começo da palavra, então referências como `AR-420` continuam funcionando.
- **Sinônimos:** um dicionário editável no painel (aba **Sinônimos**) faz abreviações e jargões valerem como a palavra por extenso, nos dois sentidos: quem busca `caixa` também acha "CX", quem busca `cirurgica` acha "AVENTAL CIR". Abreviações de até 4 letras só contam como palavra inteira (`est` não pega "estilo").
- **Ignora acentos e maiúsculas:** `esfigmomanometro` encontra "Esfigmomanômetro".
- **Categorias:** o botão **Categorias** no cabeçalho abre uma gaveta lateral (por cima da página, fecha com Esc, clique fora, « ou ao escolher) com Luvas, Cateteres, Fraldas…, da mais cheia para a menos cheia. O campo **Buscar categoria...** no topo da gaveta filtra a lista enquanto você digita (Enter escolhe a primeira; limpa ao fechar). A categoria filtra a base por tipo de produto e aparece como um selo abaixo do campo de busca (com × para remover); depois é só digitar para refinar dentro dela. O botão já aparece ao abrir a página; se a gaveta for aberta antes de a base terminar de carregar, mostra um esqueleto animado no lugar da lista. O link compartilhado guarda categoria e busca (`?cat=Luvas&q=nitril`).
- **Quatro campos ao mesmo tempo:** SKU, descrição técnica, referência (Ref.) e tags.
- **Ordenado por relevância:** código exato, referência exata e tags vêm antes de coincidências soltas na descrição.
- **Termos destacados** nos resultados; tags que casaram com a busca aparecem primeiro.
- **Uma linha por produto no computador:** a descrição (até 60 caracteres) nunca quebra de linha. As tags aparecem inteiras (sem cortar palavra), até 4 em no máximo 2 linhas, com as que combinam com a busca primeiro; se sobrar alguma, aparece a tag **…**, que mostra todas ao passar o mouse.
- **Referência legível:** referências só numéricas aparecem sem zeros à esquerda (`000000000038833014` → `38833014`); as com letras ficam como estão (`AR420`). A busca aceita as duas formas.
- **Tolera erros de digitação:** se nada for encontrado, sugere palavras parecidas da própria base (`esfigmomanomtero` → `esfigmomanometro`) e avisa o que foi buscado. Quando a busca traz poucos resultados (menos de 50), os produtos com palavras de grafia parecida aparecem **depois** dos exatos, numa seção "Parecidos com a sua busca" (só para termos de 5 letras ou mais).
- **Paginação e catálogo completo:** os resultados vêm em páginas de 50 (antes a lista parava em 100). O botão **Explorar catálogo completo** (ou "Todos os produtos" na gaveta) lista a base inteira em ordem alfabética; categoria sem termo também fica em ordem alfabética. A página atual vai no link (`?q=luva&p=2`, `?ver=todos`).
- **Buscas recentes:** as últimas 8 buscas que trouxeram resultado ficam **só neste navegador**. Aparecem ao clicar no campo vazio (ou com ↓), como no Google; o foco automático ao abrir a página não abre a lista. Uma busca entra no histórico com Enter, ao copiar um código ou o link, ou depois de 2,5 s parada; cada item pode ser removido, e há "Limpar histórico".
- **Praticidade:** clique no código para copiar o SKU e use "Copiar link desta busca" para compartilhar (`?q=sonda`); a busca do link abre já executada.
- **Leve e seguro:** debounce na digitação, 50 linhas por página e escape de HTML nos dados.
- **Lista Diária (saldo e preço campanha):** qualquer usuário, sem login, pode carregar a planilha Excel da Lista Diária (botão **Carregar Lista Diária**; aceita `.xlsx`, `.xls`, `.xlsm` e `.csv`; o CSV é lido pelo próprio site, como texto, com separador `;`, `,` ou tab, UTF-8 ou Windows-1252 e números no padrão brasileiro, `4,7983` e `1.234,5`). O site lê as colunas **Saldo disponível** e **Preco campanha** e mostra os valores na tabela (colunas *Saldo* e *Preço camp.*; no celular, uma linha sob a descrição) conforme as buscas são feitas. **Esses dados nunca vão para o banco nem para nenhum servidor:** a leitura é feita no navegador e o resultado fica só no `localStorage` do próprio usuário, que é apagado automaticamente após **24 horas**. Um aviso ao lado do botão mostra quando a lista foi atualizada e em quanto tempo ela se apaga, e o **(?)** explica que os valores são meramente consultivos e que, para maior exatidão, deve-se consultar o Protheus (TOTVS). O botão **×** apaga a lista na hora (útil em computador compartilhado). Linhas repetidas do mesmo SKU somam o saldo e usam o primeiro preço diferente de zero (o preço campanha sempre é mostrado com 4 casas decimais, ex.: R$ 12,5000); SKUs que não estão no catálogo são ignorados.
- **Link para o site oficial:** a coluna **Site** tem um ícone que abre, em nova aba, a página do produto em cbsmed.com.br (imagem e ficha técnica). O endereço é montado pela descrição técnica do jeito do WordPress (sem acento, minúsculas, `/` e `.` viram traço, vírgula, `%`, `+` e parênteses saem: `FILME TRANSP TEGADERM CHG 8,5X11,5 C/CLOREX 2% 3M 1657R(25)` → `/produto/filme-transp-tegaderm-chg-85x115-c-clorex-2-3m-1657r25/`). Como o site às vezes muda o endereço (ex.: acrescenta `-2`), o painel tem **Sincronizar com o site**, que guarda o endereço exato de cada código; depois disso, produto que não está no site abre a busca do site.
- **Copiar o valor unitário:** com a Lista Diária carregada, clicar no preço campanha copia o número (ex.: `4,7983`), igual ao clique no SKU.
- **Modo contingência:** se o banco estiver fora do ar, o site lê o `db.json` e avisa na tela.

### Painel de administração (`/admin/`)

Painel para manter a base sem mexer em arquivos JSON. O acesso é pelo botão **Login** no cabeçalho do site (ou direto em `/admin/`) e exige e-mail e senha. Depois de entrar, você encontra:

- **Visão geral** no topo, com o total de produtos, quantos estão sem tags e quantas tags existem;
- **Acesso com login** (Supabase Auth): só quem tem usuário e senha altera a base; o site público só lê;
- **CRUD de produtos e tags**, com chips, sugestões e filtro de produtos sem tags;
- **Sinônimos:** grupos de palavras equivalentes para a busca do site (`cx, caixa`), com a contagem de produtos de cada palavra;
- **Categorias:** uma por produto (`-` quando não há), com aba própria para criar, renomear, mesclar e excluir, filtro na lista e campo no cadastro e na edição em massa;
- **Gerenciamento de tags:** lista com contagem, renomear, mesclar e excluir em todos os produtos, com alerta de possíveis duplicadas;
- **Edição de tags em massa**, com seleção múltipla e prévia do resultado;
- **Importação de CSV** do sistema (inclui novos SKUs, atualiza descrição e referência e remove descontinuados), com resumo e confirmação antes de gravar. Colunas opcionais **Categoria** e **Tags**: as tags do CSV são só **acrescentadas** às existentes, nunca removidas; CSV enxuto só com `Codigo` + `Categoria`/`Tags` (botão **Exportar p/ categorizar**) e opção de não alterar referências; referências que o Excel estragou (notação científica, pontos de milhar, zeros perdidos) são detectadas e não sobrescrevem o banco;
- **Histórico** de edições e exclusões, com restauração (inclusive em lote) e filtro por data;
- **Exportação em CSV** de toda a base, para backup.

## 🏗️ Arquitetura

```
GitHub Pages (HTML + CSS + JS, sem build)
        │  fetch (API REST do Supabase)
        ▼
Supabase (PostgreSQL + PostgREST)
```

| Arquivo / pasta | Função |
| --- | --- |
| `index.html`, `script.js`, `style.css` | Site público de busca |
| `lista-diaria.js`, `vendor/xlsx.full.min.js` | Lista Diária: leitura local do Excel (SheetJS 0.18.5, Apache-2.0, carregado só quando alguém envia uma planilha) e armazenamento de 24 h no navegador |
| `admin/` | Painel de administração (`index.html`, `admin.js`, `admin.css`), acessado por `/admin/` |
| `api.js` | Camada de acesso ao Supabase (login, listar, CRUD, importar, histórico, tags) |
| `config.js` | Endereço do projeto e chave pública (`anon`) do Supabase |
| `supabase/schema.sql` | Tabelas, políticas, triggers e funções do banco |
| `supabase/migracoes/` | Scripts incrementais para bancos já criados (`002` edição em massa, `003` login, `004` gerenciar tags, `005` categorias, `006` categorias iniciais, `007` correção de referências estragadas pelo Excel, `008` sinônimos da busca, `009` links do site oficial) |
| `supabase/produtos_seed.csv` | Carga inicial dos produtos |
| `db.json` | Cópia estática usada como contingência |
| `design-system/` | CBS Design System vendorizado ([detalhes](design-system/README.md)) |

**Banco de dados:** tabela `produtos` (`sku`, `descricao_tecnica`, `referencia`, `tags`, `categoria`, `fixo`), tabela `categorias`, tabela `sinonimos` (grupos de palavras equivalentes) e `produtos_historico` (preenchida por trigger a cada edição/exclusão). A importação de CSV e a edição de tags em massa são funções SQL (RPC), então rodam de forma atômica: ou tudo é gravado ou nada. Produtos marcados como **fixo** nunca são excluídos pela importação.

## 🎨 Identidade visual

O front-end segue o **CBS Design System** (Manual de Identidade Visual CBS, out/2025): tokens de cor, tipografia Quicksand, espaçamento, raios e movimento, marca em SVG e ícones Lucide. Regras que valem aqui: títulos em caixa alta, corpo em Quicksand Light, quadrado do logotipo em laranja `#dc9c01`, foco com anel azul e hover sem mudança de tamanho.

## 🚀 Como rodar

**Produção:** acesse [danilobuch.github.io/agora-voce-sabe](https://danilobuch.github.io/agora-voce-sabe/). Para administrar a base, use o botão **Login** no cabeçalho (`/admin/`).

**Local:**

1. `git clone https://github.com/DaniloBuch/agora-voce-sabe.git`
2. Abra a pasta no VS Code e use a extensão **Live Server** em `index.html` (necessário para a Fetch API não ser bloqueada por CORS).
3. Para usar o banco, preencha o `config.js` com o endereço do projeto Supabase (sem `/rest/v1`) e a chave pública.

**Criar o banco do zero:** siga o passo a passo em [`SETUP-SUPABASE.md`](SETUP-SUPABASE.md) (criar o projeto, rodar o SQL, carregar os produtos e conectar o site). Para bancos já existentes, rode os scripts de `supabase/migracoes/` no SQL Editor.

## 🔐 Segurança

- A **leitura** dos produtos é pública (é o que o site usa); **qualquer alteração** exige login (Supabase Auth) e é protegida por regras de acesso no próprio banco (RLS), não só pela interface.
- O cadastro público de usuários deve ficar **desativado** no Supabase, para que só as contas criadas por você existam.
- **Saldo e preço campanha da Lista Diária não são gravados no banco.** Ficam só no navegador de quem carregou a lista, por no máximo 24 horas, e são apenas consultivos (a fonte oficial é o Protheus/TOTVS). Se um dia esses dados precisarem ficar no servidor, será necessário separar usuários por privilégio.
- A chave `anon` no `config.js` é pública por natureza e não dá permissão de gravação.
- O **Histórico** guarda a versão anterior de tudo o que for alterado ou excluído, e a exportação em CSV serve de backup extra.

## 🛣️ Roadmap

- [x] Busca por partículas, sem acento, com relevância e destaque
- [x] Banco PostgreSQL (Supabase) no lugar do JSON estático
- [x] Painel de administração com CRUD, importação de CSV e histórico
- [x] Edição de tags em massa e gerenciamento de tags (renomear, mesclar, excluir)
- [x] Login no painel (Supabase Auth) e novo visual do painel e exportação de backup em CSV
- [x] CBS Design System aplicado
- [x] Copiar SKU, link compartilhável da busca e tolerância a erro de digitação
- [x] Categorias de produtos (filtro no site, gestão no painel, CSV)
- [ ] Valor e saldo em estoque apenas para usuários logados (exige perfis de acesso e avaliação de dado sensível)
- [ ] Registrar buscas sem resultado, para descobrir apelidos que faltam virar tag
- [ ] Backup automático agendado
- [ ] Atalhos e melhorias de uso no celular

---

_Desenvolvido por **Danilo Buch** — unindo a visão estratégica de Negócios com a Engenharia de Software._
